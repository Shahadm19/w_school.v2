<?php
$title_pages = 'Detiles student';
require_once __DIR__ . '/../template/header.php';

// if (!isset($_GET['id']) || !$_GET['id']) {
//     die('Missing id parameter');
// }


$student_id = $_SESSION['user_id'];  

$students_info = $mysqli->prepare("select *, concat(users.frist_name, ' ', users.last_name) as full_name
                    from users 
                    where users.id = ? 
                    ");

$students_info->bind_param('i', $id_user);
$id_user = $student_id;
$students_info->execute();
$student_info = $students_info->get_result()->fetch_assoc();


$student_name = $student_info['full_name'];
$email = $student_info['email'];
$phone = $student_info['phone'];


$students = $mysqli->query("select exam_result.id as exam_result_id, student_id, exam_id, score, 
                            concat(s.frist_name, ' ', s.last_name) as student_name, 
                            concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                            courses.short_name as course_short_name, courses.title as course_title,
                            classrooms.title as classroom_title
                            from exam_result
                            left join exams on exam_result.exam_id = exams.id 
                            left join classes on exams.class_id = classes.id 
                            left join classrooms on classes.classroom_id = classrooms.id
                            left join courses on classes.course_id = courses.id
                            left join users s on exam_result.student_id = s.id
                            inner join users t on classes.teacher_id = t.id
                            where exam_result.student_id = '$student_id'
                            order by exam_result.student_id
                            ")->fetch_all(MYSQLI_ASSOC);
?>


<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Start Content 1 -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="d-flex align-items-end row">
                        <div class="col-sm-7">
                            <div class="card-body">
                                <h5 class="card-title text-primary"> Student: <?php echo $student_name ?></h5>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless border-bottom">
                                        <thead>
                                            <tr>
                                                <th class="text-nowrap">Phone</th>
                                                <th class="text-nowrap text-center"><?php echo $phone ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="text-nowrap">Email</td>
                                                <td class="text-nowrap text-center"><?php echo $email ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5 text-center text-sm-left">
                            <div class="card-body pb-0 px-0 px-md-4">
                                <img src="<?php echo $config['app_url'] ?>assets/img/illustrations/man-with-laptop-light.png" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content 1 -->

        <!-- Start Content 2 -->

        <div class="row">
            <!-- Bootstrap Table with Header - Light -->
            <div class="col-md-12 col-lg-12 order-2 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <?php include  __DIR__ . '/../template/messages.php' ?>
                        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search coures" class="form-control" title="Type in a name">

                    </div>

                    <div class="table-responsive text-nowrap">
                        <table id="myTable" class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Course</th>
                                    <th>Short course</th>
                                    <th>Teacher</th>
                                    <th>Classroom</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php foreach ($students as $student) : ?>
                                    <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo $student['course_title'] ?> <strong>
                                            </strong></td>

                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo $student['course_short_name'] ?> <strong>
                                            </strong></td>

                                        <td><?php echo $student['teacher_name'] ?></td>
                                        <td>
                                            <div class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php echo $student['classroom_title'] ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content 2 -->
    </div>

</div>




<?php require_once __DIR__ . '/../template/footer.php' ?>