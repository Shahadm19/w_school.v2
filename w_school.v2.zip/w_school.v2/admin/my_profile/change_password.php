<?php
$title_pages = "Change passwords";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
}
$user_id = $_GET['id']; 

// $update_user = $mysqli->prepare("select users.password as old_password, roles.title as role_user
//                         from users 
//                         left join roles on users.role_id = roles.id 
//                         where users.id = ? limit 1"); 
// $update_user->bind_param('i', $id_user);
// $id_user = $_GET['id']; 
// $update_user->execute(); 
// $users = $update_user->get_result()->fetch_assoc(); 
// $old_password = $users['old_password']; 




if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // $old_password = mysqli_real_escape_string($mysqli, $_POST['old_password']);
    $password = mysqli_real_escape_string($mysqli, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($mysqli, $_POST['confirm_password']);
  
    // if(empty($old_password)){array_push($errors, "Password old is required");}
    if(empty($password)){array_push($errors, "Password is required");}
    if(empty($confirm_password)){array_push($errors, "Password confirmtion is required");}
    if($password != $confirm_password){
        array_push($errors, "Passwords don't match"); 
    }
  

    // if (!count($errors)) {
  
    //     if (password_verify($old_password, $found_user['password'])) {
    //     if($password != $confirm_password){
    //         array_push($errors, "Passwords don't match"); 
    //     }
    //     } 
    //   }

  
    if (!count($errors)) {
  
      $hashed_password = password_hash($password, PASSWORD_DEFAULT);
  
      $mysqli->query("update users set password = '$hashed_password' where id ='$user_id' "); 
  
      $_SESSION['success_message'] = 'Your password has been change.'; 
      echo "<script>location.href = 'index.php?id='$user_id'' </script>"; 
  
    }
    

}

?>




<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Change password</h5>
                <div class="card-body">
                <?php include  __DIR__ . '/../../template/messages.php'?>
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Password :</label>
                                    <input type="password" name='password' class="form-control" id="defaultFormControlInput" placeholder="****"  />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Confirm password :</label>
                                    <input type="password" name='confirm_password' class="form-control" id="defaultFormControlInput" placeholder="*****"  />
                                </div>
                            </div>


                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Update password !</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php require_once __DIR__ . '/../../template/footer.php' ?>