<?php
$title_pages = "My profile";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
}



$roles = $mysqli->query("select * from roles order by id")->fetch_all(MYSQLI_ASSOC);

$update_user = $mysqli->prepare("select *, roles.title as role_user
                        from users 
                        left join roles on users.role_id = roles.id 
                        where users.id = ? limit 1"); 
$update_user->bind_param('i', $id_user);
$id_user = $_GET['id']; 
$update_user->execute(); 
$users = $update_user->get_result()->fetch_assoc(); 
$frist_name = $users['frist_name']; 
$last_name = $users['last_name'];
$phone = $users['phone'];
$email = $users['email']; 
$role_id = $users['role_id'];
$role_user = $users['role_user'];



if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(empty($frist_name)){array_push($errors, "Frist name is required");}
    if(empty($last_name)){array_push($errors, "Last name is required");}
    if(empty($phone)){array_push($errors, "Phone number is required");}
    if(empty($email)){array_push($errors, "E-mail is required");}
    // if(empty($role_id)){array_push($errors, "Select role is required");}



    if (!count($errors)) {
        $update_user = $mysqli->prepare('update users set frist_name=?, last_name=?, phone=?, email=? where id = ?'); 
        $update_user->bind_param('ssssi', $dbFrist_name, $dbLast_name, $dbPhone, $dbEmail, $dbUser_id); 
        $dbFrist_name = $_POST['frist_name']; 
        $dbLast_name = $_POST['last_name']; 
        $dbPhone = $_POST['phone']; 
        $dbEmail = $_POST['email'];  
        $dbUser_id = $_GET['id']; 
        $update_user->execute();

        $_SESSION['success_message'] = "Has been user modify successfully";
       
    
        if($update_user->error){
            array_push($errors, $update_user->error); 
    }else{
        echo "<script>location.href = 'index.php?id=$id_user' </script>"; 

    }
    }

}

?>




<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">My profile</h5>
                <?php include  __DIR__ . '/../../template/messages.php'?>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Frist name :</label>
                                    <input type="text" name='frist_name' class="form-control" id="defaultFormControlInput" placeholder="Mohammed" value="<?php echo $frist_name?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Last name :</label>
                                    <input type="text" name='last_name' class="form-control" id="defaultFormControlInput" placeholder="Alsaleh" value="<?php echo $last_name?>" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Phone :</label>
                                    <input type="text" name='phone' class="form-control" id="defaultFormControlInput" placeholder="+9665*****" value="<?php echo $phone?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Email :</label>
                                    <input type="email" name='email' class="form-control" id="defaultFormControlInput" placeholder="name@example.com" value="<?php echo $email?>"/>
                                </div>
                            </div> 
                            <div class="row">
                                <!-- <div class="col-6 pt-3">
                                <a href="<?php echo $config['app_url']?>admin/my_profile/change_password.php?id=<?php echo $id_user?>" class="d-flex">
                  <i class="bx "></i>
                 Change password
                </a></div> -->
                          
                            <!-- <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select role :</label>
                                <select class="form-select" name="role_id" id="exampleFormControlSelect1" value="<?php echo $role_id?>">
                                <option value="<?php echo $role_id?>"><?php echo $role_user?></option>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['id']?>"><?php echo $role['title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div> -->

                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Update!</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php require_once __DIR__ . '/../../template/footer.php' ?>