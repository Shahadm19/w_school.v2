<?php
$title_pages = 'Add class student';
require_once __DIR__ . '/../../template/header.php';
$errors = [];


$students = $mysqli->query("select *, concat(users.frist_name, ' ', users.last_name) as full_name from users where role_id = 9")->fetch_all(MYSQLI_ASSOC);
$classes = $mysqli->query("select classes.id as class_id, 
                    courses.title as course_title 
                    from classes 
                    left join courses on classes.course_id = courses.id 
                    order by classes.id")->fetch_all(MYSQLI_ASSOC);



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $student_id = mysqli_real_escape_string($mysqli, $_POST['student_id']); 
    $class_id = mysqli_real_escape_string($mysqli, $_POST['class_id']); 

    if(empty($student_id)){array_push($errors, "Student is required");}
    if(empty($class_id)){array_push($errors, "Class is required");}

    if (!count($errors)) {
        $class_exists = $mysqli->query("select student_id, class_id from class_student where student_id ='$student_id' and class_id='$class_id' limit 1"); 
        if($class_exists->num_rows){
            array_push($errors, "Student class is already registered"); 
        }
    }

    if(!count($errors)){
    $add_class = $mysqli->prepare("insert into class_student (student_id, class_id) values (?,?)"); 
    $add_class->bind_param('ii', $dbStudent_id, $dbClass_id); 
    $dbStudent_id = $_POST['student_id']; 
    $dbClass_id = $_POST['class_id']; 

    $add_class->execute();

    // $_SESSION['logged_in'] = true; 
    $_SESSION['success_message'] = "Student class add successfully"; 
    // header('location:index.php'); 
    echo "<script>location.href = 'index.php' </script>"; 

  }
} 


?> 



<!-- Content wrapper -->
<?php if($_SESSION['role_id'] == 7) { ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Add student class</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">                   

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Student :</label>
                                <select class="form-select" name="student_id" id="exampleFormControlSelect1" value="<?php echo $student_id?>">
                                <option value="">Select one</option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo $student['id']?>"><?php echo $student['full_name']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Class :</label>
                                <select class="form-select" name="class_id" id="exampleFormControlSelect1" value="<?php echo $class_id?>">
                                <option value="">Select one</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['class_id']?>"><?php echo $class['course_title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Add student class</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
 } else {
    die('You are not allowed to access this page');} 
    ?>

<?php require_once __DIR__ . '/../../template/footer.php' ?>