<?php
$title_pages = 'Class student';
require_once __DIR__ . '/../../template/header.php';

$class_students = $mysqli->query("select class_student.id as class_student_id, users.id as user_id, 
                    concat(users.frist_name, ' ' , users.last_name) as full_name,
                    GROUP_CONCAT(courses.title SEPARATOR ', ') as courses_title,
                    GROUP_CONCAT( courses.short_name SEPARATOR ', ') as course_short_name
                    from class_student 
                    left join users on class_student.student_id = users.id 
                    left join classes on class_student.class_id = classes.id 
                    left join courses on classes.course_id = courses.id
                    group by class_student.student_id
                ")->fetch_all(MYSQLI_ASSOC);


$courses = $mysqli->query("select * from courses order by id")->fetch_all(MYSQLI_ASSOC);

?>


<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Bootstrap Table with Header - Light -->
            <div class="col-md-12 col-lg-12 order-2 mb-4">
                <div class="card h-100">
                    <div class="row card-header">
                        <?php include  __DIR__ . '/../../template/messages.php' ?>

                        <div class="col-md-9">
                            <h5>Student : <?php echo count($class_students) ?></h5>
                        </div>
                        <?php if ($_SESSION['role_id'] == 7) { ?>
                            <div class="col-md-3">
                                <a href="create.php" type="button" class=" btn btn-success"> Add new student</a>
                            </div>
                        <?php } ?>
                        <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search student">
 
                    </div>

                    <div class="table-responsive text-nowrap">
                        <table id="myTable" class="table">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Student</th>
                                    <th>Class</th>
                                    <th>-</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php foreach ($class_students as $class_student) : ?>
                                 <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $class_student['class_student_id'] ?></strong></td>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $class_student['full_name'] ?></strong></td>
                                        <td><?php echo $class_student['courses_title'] ?></td>
                                        <?php if ($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8) { ?>
                                            <td>
                                                <a href="read_more.php?id=<?php echo $class_student['user_id'] ?>" type="button" class="btn btn-sm btn-primary"><i class=""></i>Read more</a>
                                                <form action="" method="post" style="display: inline-block">
                                                    <input type="hidden" name="id" value="<?php echo $class_student['class_student_id'] ?>">
                                                    <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger"><i class="bx bx-trash me-1"></i>Delete</button>
                                                </form>
                                            </td>

                                        <?php } ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>



    <!-- /Content Card  -->


    <?php

    if (isset($_POST['class_id'])) {

        $st = $mysqli->prepare('delete from classes where id = ?');
        $st->bind_param('i', $id_class);
        $id_class = $_POST['class_id'];
        $st->execute();

        echo "<script>location.href = 'index.php' </script>";
    }
    ?>


    <script>
        function myFunction() {
            // Declare variables
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>

    <?php require_once __DIR__ . '/../../template/footer.php' ?>