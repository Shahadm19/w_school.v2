<?php
$title_pages = 'Detiles student';
require_once __DIR__ . '/../../template/header.php';

if (!isset($_GET['id']) || !$_GET['id']) {
    die('Missing id parameter');
}

$student_id = $_GET['id']; 

if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) { 
$students_exam = $mysqli->query("select exam_result.id as exam_result_id,  exam_id, student_id, 
                    concat(s.frist_name, ' ', s.last_name) as student_name,
                    score, s.phone as student_phone, s.email as student_email,
                    courses.short_name as course_short_name,  courses.title as course_title, classrooms.title as classroom_title,
                    concat(t.frist_name, ' ', t.last_name) as teacher_name
                    from exam_result
                    left join exams on exam_result.exam_id = exams.id 
                    left join classes on exams.class_id = classes.id 
                    left join classrooms on classes.classroom_id = classrooms.id
                    left join courses on classes.course_id = courses.id
                    left join users s on exam_result.student_id = s.id
                    inner join users t on classes.teacher_id = t.id
                    where exam_result.student_id = '$student_id'          
                  ")->fetch_all(MYSQLI_ASSOC);
} 


$students = $mysqli->prepare("select exam_result.id as exam_result_id, student_id, exam_id, score, 
                    concat(s.frist_name, ' ', s.last_name) as student_name, s.phone as student_phone, s.email as student_email,
                    concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                    courses.short_name as course_short_name, classrooms.title as classroom_title
                    from exam_result
                    left join exams on exam_result.exam_id = exams.id 
                    left join classes on exams.class_id = classes.id 
                    left join classrooms on classes.classroom_id = classrooms.id
                    left join courses on classes.course_id = courses.id
                    left join users s on exam_result.student_id = s.id
                    inner join users t on classes.teacher_id = t.id
                    where exam_result.student_id = ? 
                    order by exam_result.student_id
                    ");

$students->bind_param('i', $id_exam_result);
$id_exam_result = $_GET['id'];
$students->execute();
$student = $students->get_result()->fetch_assoc();


$student_name = $student['student_name'];
$email = $student['student_email'];
$phone = $student['student_phone'];
?>


<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Start Content 1 -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="d-flex align-items-end row">
                        <div class="col-sm-7">
                            <div class="card-body">
                                <h5 class="card-title text-primary"> Student: <?php echo $student_name ?></h5>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless border-bottom">
                                        <thead>
                                            <tr>
                                                <th class="text-nowrap">Phone</th>
                                                <th class="text-nowrap text-center"><?php echo $phone ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="text-nowrap">Email</td>
                                                <td class="text-nowrap text-center"><?php echo $email ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-5 text-center text-sm-left">
                            <div class="card-body pb-0 px-0 px-md-4">
                                <img src="<?php echo $config['app_url'] ?>assets/img/illustrations/man-with-laptop-light.png" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content 1 -->

        <!-- Start Content 2 -->

        <div class="row">
            <!-- Bootstrap Table with Header - Light -->
            <div class="col-md-12 col-lg-12 order-2 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <?php include  __DIR__ . '/../../template/messages.php' ?>
                        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search coures" class="form-control" title="Type in a name">

                    </div>

                    <div class="table-responsive text-nowrap">
                        <table id="myTable" class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Course</th>
                                    <th>Short course</th>
                                    <th>Teacher</th>
                                    <?php if($_SESSION['role_id'] == 7): ?>
                                    <th>Score</th>
                                    <?php endif; ?>
                                    <th>Classroom</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php foreach ($students_exam as $student_exam) : ?>
                                    <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo $student_exam['course_title'] ?> <strong>
                                            </strong></td>

                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo $student_exam['course_short_name'] ?> <strong>
                                            </strong></td>

                                        <td><?php echo $student_exam['teacher_name'] ?></td>
                                        <?php if($_SESSION['role_id'] == 7): ?>
                                        <td>
                                            <div class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                             %   <?php echo $student_exam['score'] ?>
                                            </div>
                                        </td>
                                        <?php endif ; ?>
                                        <td>
                                            <div class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php echo $student_exam['classroom_title'] ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Content 2 -->
    </div>

</div>




<?php require_once __DIR__ . '/../../template/footer.php' ?>