<?php
$title_pages = "Edit role";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
}

$update_role = $mysqli->prepare("select * from roles where id = ? limit 1"); 
$update_role->bind_param('i', $id_role);
$id_role = $_GET['id']; 
$update_role->execute(); 
$roles = $update_role->get_result()->fetch_assoc(); 
$title = $roles['title']; 


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (empty($_POST['title'])){array_push($errors, 'Name role is required');}

    // if (!count($errors)) {
    //     $role_exists = $mysqli->query("select * from roles where title='$title' limit 1");
    //     if ($role_exists->num_rows) {
    //         array_push($errors, "Name role is already registered");
    //     }
    // }

    if (!count($errors)) {
        $update_role = $mysqli->prepare('update roles set title = ? where id = ?'); 
        $update_role->bind_param('si', $dbTitle, $id_role);
        $dbTitle = $_POST['title']; 
        $id_role = $_GET['id']; 
        $update_role->execute(); 
        $_SESSION['success_message'] = "Has been role modify successfully";
    
        if($update_role->error){
            array_push($errors, $update_role->error); 
    }else{
        echo "<script>location.href = 'index.php' </script>"; 

    }
    }

}

?>


<?php if($_SESSION['role_id'] == 7) { ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
    <div class="col-md-12 col-lg-12 order-2 mb-4">
    <div class="card">
        <h5 class="card-header">Edit role:</h5>
        <div class="card-body">
            <?php include __DIR__ . '/../../template/errors.php' ?>
            <div>
                <form action="" method="post">
                    <label for="defaultFormControlInput" class="form-label">Name</label>
                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="Teacher" value="<?php echo $title?>" aria-describedby="defaultFormControlHelp" />

                    <div class="demo-vertical-spacing">
                        <div class="d-block">
                            <button class="btn btn-success" for="btn-check">Edit role</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    </div>
</div>

<?php 
} else {
    die("You are not allowed to access this page");
}
?>

<?php require_once __DIR__ . '/../../template/footer.php' ?>