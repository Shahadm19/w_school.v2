<?php
$errors = [];
$title = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($mysqli, $_POST['title']);
    if (empty($title)) {
        array_push($errors, 'Name role is required');
    }

    if (!count($errors)) {
        $role_exists = $mysqli->query("select * from roles where title='$title' limit 1");
        if ($role_exists->num_rows) {
            array_push($errors, "Name role is already registered");
        }
    }

    if(!count($errors)){
    $add_role = $mysqli->prepare("insert into roles (title) values (?)"); 
    $add_role->bind_param('s',$dbTitle); 
    $dbTitle = $title; 
    $add_role->execute();

    $_SESSION['success_message'] = "New role add successfully"; 
    echo "<script>location.href = 'index.php' </script>"; 

    }

 
}

?>
<?php if($_SESSION['role_id'] == 7) { ?>
<div class="col-md-6 col-lg-6 order-2 mb-4">
    <div class="card">
        <h5 class="card-header">Add new role:</h5>
        <div class="card-body">
            <?php include __DIR__ . '/../../template/errors.php' ?>
            <div>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">
                    <label for="defaultFormControlInput" class="form-label">Name</label>
                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="Teacher" aria-describedby="defaultFormControlHelp" />

                    <div class="demo-vertical-spacing">
                        <div class="d-block">
                            <button class="btn btn-success" for="btn-check">Add role</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php 
} else {
    die("You are not allowed to access this page");
}
?>