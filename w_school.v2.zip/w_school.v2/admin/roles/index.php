<?php
$title_pages = "Roles";
require_once __DIR__ . '/../../template/header.php';

$roles = $mysqli->query("select * from roles order by id")->fetch_all(MYSQLI_ASSOC);
?>


<?php if($_SESSION['role_id'] == 7) { ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
        </div>
    </div>

    <div class="row">
        <!-- Bootstrap Table with Header - Light -->
        <div class="col-md-6 col-lg-6 order-2 mb-4">
            <div class="card h-100">
            <?php include  __DIR__ . '/../../template/messages.php'?>
                <h5 class="card-header">All Roules : <?php echo count($roles)?></h5>
                <div class="table-responsive text-nowrap">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php foreach ($roles as $role) : ?>
                                <tr>
                                    <td><?php echo $role['id'] ?></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $role['title'] ?></strong></td>
                                    <td>
                                        <a href="edit.php?id=<?php echo $role['id']?>" type="button" class="btn btn-sm btn-warning"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <form action="" method="post" style="display: inline-block">
                                            <input type="hidden" name="id_role" value="<?php echo $role['id']?>">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger"><i class="bx bx-trash me-1"></i>Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php require_once 'create.php' ?>
    </div>
</div>

<?php 
if(isset($_POST['id_role'])){

    $st = $mysqli->prepare('delete from roles where id = ?'); 
    $st->bind_param('i', $id_role); 
    $id_role = $_POST['id_role']; 
    $st->execute();

    echo "<script>location.href = 'index.php' </script>"; 
}
?>

<?php }else{
    die("You are not allowed to access this page");
}?>
<?php require_once __DIR__ . '/../../template/footer.php' ?>