<?php
$title_pages = 'Users';
require_once __DIR__ . '/../../template/header.php';


// $users = $mysqli->query("select * from users order by id")->fetch_all(MYSQLI_ASSOC);

$users = $mysqli->query("select *, user.id as user_id , role.id as roles_id
                        from users user 
                        left join roles role
                        on user.role_id = role.id")->fetch_all(MYSQLI_ASSOC);
?>

<?php if($_SESSION['role_id'] == 7) { ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Bootstrap Table with Header - Light -->
            <div class="col-md-12 col-lg-12 order-2 mb-4">
                <div class="card h-100">
                    <div class="row card-header">
                    <?php include  __DIR__ . '/../../template/messages.php'?>

                        <div class="col-md-9">
                            <h5>Users : <?php echo count($users) ?></h5>
                        </div>
                        <div class="col-md-3">
                            <a href="create.php" type="button" class=" btn btn-success"><i class='bx bxs-user-plus'></i> Add new user</a>
                        </div>
                        <div class="col-7">
                        <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search user">

                        </div>

                    </div>

                    <div class="table-responsive text-nowrap">
                        <table id="myTable" class="table">
                            <thead class="table-light">
                                <tr>
                                    <th>Full name</th>
                                    <th>phone</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php foreach ($users as $user) : ?>
                                    <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $user['frist_name']; ?> <?php echo $user['last_name'] ?></strong></td>
                                        <td><?php echo $user['phone'] ?></td>
                                        <td>
                                            <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php echo $user['email'] ?>
                                            </ul>
                                        </td>
    
                                        
                                        <td>
                                            <?php if($user['title'] == 'Admin'){?> <span class="badge bg-label-dark me-1"><?php echo $user['title'] ?></span> <?php }?>
                                            <?php if($user['title'] == 'Teacher'){?> <span class="badge bg-label-primary me-1"><?php echo $user['title'] ?></span> <?php }?>
                                            <?php if($user['title'] == 'Student'){?> <span class="badge bg-label-info me-1"><?php echo $user['title'] ?></span> <?php }?>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                    <i class="bx bx-dots-vertical-rounded"></i>
                                                </button>

                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="edit.php?id=<?php echo $user['user_id'] ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                                    <form action="" method="post" style="display: inline-block">
                                                        <input type="hidden" name="id" value="<?php echo $user['user_id'] ?>">
                                                        <button onclick="return confirm('Are you sure?')" class="dropdown-item"><i class="bx bx-trash me-1"></i>Delete</button>
                                                    </form>

                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


    <?php
    
    if (isset($_POST['id'])) {

        $st = $mysqli->prepare('delete from users where id = ?');
        $st->bind_param('i', $id_user);
        $id_user = $_POST['id'];
        $st->execute();

        echo "<script>location.href = 'index.php' </script>";
    }

    ?>


<?php 
} else {
    die("You are not allowed to access this page");
}
?>


<script>
        function myFunction() {
            // Declare variables
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[0];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
    <?php require_once __DIR__ . '/../../template/footer.php' ?>