<?php
$title_pages = 'Create user';
require_once __DIR__ . '/../../template/header.php';
$errors = [];
$frist_name = ''; 
$last_name = ''; 
$phone = ''; 
$email = ''; 
$role_id = ''; 
$password = '';

$roles = $mysqli->query("select * from roles order by id")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $frist_name = mysqli_real_escape_string($mysqli, $_POST['frist_name']); 
    $last_name = mysqli_real_escape_string($mysqli, $_POST['last_name']); 
    $phone = mysqli_real_escape_string($mysqli, $_POST['phone']); 
    $email = mysqli_real_escape_string($mysqli, $_POST['email']); 
    $role_id = mysqli_real_escape_string($mysqli, $_POST['role_id']); 
    $password = mysqli_real_escape_string($mysqli, $_POST['password']); 
    $confirm_password = mysqli_real_escape_string($mysqli, $_POST['confirm_password']); 

    if(empty($frist_name)){array_push($errors, "Frist name is required");}
    if(empty($last_name)){array_push($errors, "Last name is required");}
    if(empty($phone)){array_push($errors, "Phone number is required");}
    if(empty($email)){array_push($errors, "E-mail is required");}
    if(empty($role_id)){array_push($errors, "Select role is required");}
    if(empty($password)){array_push($errors, "Password is required");}
    if(empty($confirm_password)){array_push($errors, "Password confirmtion is required");}
    if($password != $confirm_password){
        array_push($errors, "Passwords don't match"); 
    }



    if (!count($errors)) {
        $user_exists = $mysqli->query("select id, phone from users where phone ='$phone' limit 1"); 
        if($user_exists->num_rows){
            array_push($errors, "Phone number already registered"); 
        }
    }

    if (!count($errors)) {
        $user_exists = $mysqli->query("select id, email from users where email ='$email' limit 1"); 
        if($user_exists->num_rows){
            array_push($errors, "Email is already registered"); 
        }
    }

    if(!count($errors)){
    $password = password_hash($password, PASSWORD_DEFAULT); 
    $add_user = $mysqli->prepare("insert into users (frist_name, last_name, phone, email, role_id, password) values (?,?,?,?,?,?)"); 
    $add_user->bind_param('ssssis', $dbFrist_name, $dbLast_name, $dbPhone, $dbEmail, $dbRole_id, $dbPassword); 
    $dbFrist_name = $frist_name; 
    $dbLast_name = $last_name; 
    $dbPhone = $phone; 
    $dbEmail = $email; 
    $dbRole_id = $_POST['role_id']; 
    $dbPassword = $password; 
    $add_user->execute();
    } 

    
    if(!count($errors)){
    $user_exist = $mysqli->query("select id, email from users where email='$email' limit 1");

    if ($user_exist->num_rows) {

      $user_id = $user_exist->fetch_assoc()['id']; 

      $token_exist = $mysqli->query("delete from password_resets where user_id='$user_id'"); 

      $token = bin2hex(random_bytes(16)); 
      $expires_at = date('Y-m-d H:i:s', strtotime('+1 day'));

      $mysqli->query("insert into password_resets(user_id, token, expires_at ) values ('$user_id', '$token', '$expires_at')"); 
      


    $change_password_url = $config['app_url']. 'confirm_user.php?token='.$token; 
     
    

    $headers = 'MINE-Version :1.0' . "\r\n". 
    $headers .= 'Content-type: text/html; charser=UTF-8' . "\r\n"; 
    $headers .= 'From: '.$config['admin_email']. "\r\n". 
                'Replay-To: ' .$config['admin_email']."\r\n".
                'X_Mailer: PHP/' . phpversion();
            
    $html_message = '<html><body>' ; 
    $html_message .= '<p style="color:#ff000;">'.$change_password_url.'</p>' ;
    $html_message .= '</body></html>';
    
    mail($config['admin_email'], 'Confirm user', $html_message, $headers); 
  } } 




    $_SESSION['success_message'] = "User add successfully"; 
    echo "<script>location.href = 'index.php' </script>"; 


} 







?> 


<?php if($_SESSION['role_id'] == 7) { ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Add new user</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">
                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Frist name :</label>
                                    <input type="text" name='frist_name' class="form-control" id="defaultFormControlInput" placeholder="Mohammed" value="<?php echo $frist_name?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Last name :</label>
                                    <input type="text" name='last_name' class="form-control" id="defaultFormControlInput" placeholder="Alsaleh" value="<?php echo $last_name?>" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Phone :</label>
                                    <input type="text" name='phone' class="form-control" id="defaultFormControlInput" placeholder="+9665*****" value="<?php echo $phone?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Email :</label>
                                    <input type="email" name='email' class="form-control" id="defaultFormControlInput" placeholder="name@example.com" value="<?php echo $email?>"/>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select role :</label>
                                <select class="form-select" name="role_id" id="exampleFormControlSelect1" value="<?php echo $role_id?>">
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['id']?>"><?php echo $role['title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>


                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Password :</label>
                                    <input type="password" name='password' class="form-control" id="defaultFormControlInput" placeholder="*****" aria-describedby="defaultFormControlHelp" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Confirm password :</label>
                                    <input type="password" name='confirm_password' class="form-control" id="defaultFormControlInput" placeholder="*****" aria-describedby="defaultFormControlHelp" />
                                </div>
                            </div>

                            <!-- <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Date of birth :</label>
                                    <input type="date" name='dob' class="form-control" id="defaultFormControlInput"  value="<?php echo $dob?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Image :</label>
                                    <input type="file" name='image' class="form-control" id="defaultFormControlInput" value="<?php echo $image?>" />
                                </div>
                            </div> -->

                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Add user</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
} else {
    die("You are not allowed to access this page");
}
?>
<?php require_once __DIR__ . '/../../template/footer.php' ?>