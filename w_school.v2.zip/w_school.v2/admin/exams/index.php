<?php
$title_pages = "Exams";
require_once __DIR__ . '/../../template/header.php';

$exams = $mysqli->query("select *, exams.id as exam_id, 
                     courses.title as course_title,
                     users.frist_name as user_frist_name, users.last_name as user_last_name, 
                     classrooms.location as classroom_floor, classrooms.title as classroom_title
                     from exams
                     left join classes on exams.class_id = classes.id
                     left join courses on classes.course_id = courses.id 
                     left join users on classes.teacher_id = users.id 
                     left join classrooms on classes.classroom_id = classrooms.id
                     order by exams.class_id")->fetch_all(MYSQLI_ASSOC);
?>

 

<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
        </div>
    </div>

    <div class="row">
        <!-- Bootstrap Table with Header - Light -->
        <div class="col-md-8 col-lg-8 order-2 mb-4">
            <div class="card overflow-hidden mb-4 h-100" style="height: 570px"> 
            <?php include  __DIR__ . '/../../template/messages.php'?>
            <div class="card-header">
           <h5>All Exams : <?php echo count($exams)?>
                </h5>
                <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search Course">

            </div>

                <div class="table-responsive text-nowrap">

                    <table id="myTable" class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <!-- <th>Class ID</th> -->
                                <th>Course</th>
                                <th>Teacher</th>
                                <th>Classroom</th>
                                <?php if($_SESSION['role_id'] == 7 ) { ?>
                                <th>Action</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php foreach ($exams as $exam) : ?>
                                <tr>
                                    <td><?php echo $exam['exam_id'] ?></td>
                                    <!-- <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $exam['class_id'] ?></strong></td> -->
                                    <td>
                                        <?php echo $exam['course_title']?>
                                    </td>
                                    <td><?php echo $exam['user_frist_name']?> <?php echo $exam['user_last_name']?></td>
                                    <td><?php echo $exam['classroom_floor']?> ( <?php echo $exam['classroom_title']?> )</td>
                                    <td>
                                    <?php if($_SESSION['role_id'] == 7 ) { ?>

                                        <form action="" method="post" style="display: inline-block">
                                            <input type="hidden" name="exam_id" value="<?php echo $exam['exam_id']?>">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger"><i class="bx bx-trash me-1"></i>Delete</button>
                                        </form>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) { ?>
        <?php require_once 'create.php' ?>
        <?php } ?> 
    </div>
</div>

<?php 
if(isset($_POST['exam_id'])){

    $st = $mysqli->prepare('delete from exams where id = ?'); 
    $st->bind_param('i', $id_exam); 
    $id_exam = $_POST['exam_id']; 
    $st->execute();

    echo "<script>location.href = 'index.php' </script>"; 
}
?>



<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

<?php require_once __DIR__ . '/../../template/footer.php' ?>