<?php
$errors = [];
$title = '';

$user_id = $_SESSION['user_id']; 

if($_SESSION['role_id'] == 8 ) {
 
$classes = $mysqli->query("select *, classes.id as class_id, 
                    courses.title as course_title,
                    users.frist_name as user_frist_name, users.last_name as user_last_name, 
                    classrooms.location as classroom_floor, classrooms.title as classroom_title
                    from classes 
                    left join courses on classes.course_id = courses.id 
                    left join users on classes.teacher_id = users.id 
                    left join classrooms on classes.classroom_id = classrooms.id
                    where users.id = '$user_id'
                    order by classes.id ")->fetch_all(MYSQLI_ASSOC);
} else{


$classes = $mysqli->query("select *, classes.id as class_id, 
                    courses.title as course_title,
                    users.frist_name as user_frist_name, users.last_name as user_last_name, 
                    classrooms.location as classroom_floor, classrooms.title as classroom_title
                    from classes 
                    left join courses on classes.course_id = courses.id 
                    left join users on classes.teacher_id = users.id 
                    left join classrooms on classes.classroom_id = classrooms.id
                    order by classes.id ")->fetch_all(MYSQLI_ASSOC);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_id = mysqli_real_escape_string($mysqli, $_POST['class_id']);
    if (empty($class_id)) {
        array_push($errors, 'Select one is required');
    }

    if (!count($errors)) {
        $exam_exists = $mysqli->query("select * from exams where class_id='$class_id' limit 1");
        if ($exam_exists->num_rows) {
            array_push($errors, "This exam is already registered");
        }
    }

    if (!count($errors)) {
        $add_exam = $mysqli->prepare("insert into exams (class_id) values (?)");
        $add_exam->bind_param('i', $dbClass_id);
        $dbClass_id = $_POST['class_id']; 
        $add_exam->execute();

    $_SESSION['success_message'] = "Exam add successfully"; 
    echo "<script>location.href = 'index.php' </script>"; 

    }
}

?>

<?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) { ?>
<div class="col-md-4 col-lg-4 order-2 mb-4">
    <div class="card">
        <h5 class="card-header">Add exam:</h5>
        <div class="card-body">
            <?php include __DIR__ . '/../../template/errors.php' ?>
            <div>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">

                    <div class="mb-3">
                        <label for="exampleFormControlSelect1" class="form-label">Select one:</label>
                        <select class="form-select" name="class_id" id="exampleFormControlSelect1" value="<?php echo $class_id ?>">
                        <option value="">Select one</option>
                            <?php foreach ($classes as $class) : ?>
                                <option value="<?php echo $class['class_id'] ?>">
                                    <?php echo $class['course_title'] ?>
                                    ( <?php echo $class['classroom_title'] ?> )
                                    -
                                    <?php echo $class['user_frist_name'] ?> <?php echo $class['user_last_name'] ?>

                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="demo-vertical-spacing">
                        <div class="d-block">
                            <button class="btn btn-success" for="btn-check">Add exam</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php } else {
    die("You are not allowed to access this page");
}?>