<?php
$title_pages = "Edit Classroom";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
}

// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 7) {   
//       die('You are not allowed to access this page');
// }
  

$update_classrom = $mysqli->prepare("select * from classrooms where id = ? limit 1"); 
$update_classrom->bind_param('i', $id_classrom);
$id_classrom = $_GET['id']; 
$update_classrom->execute(); 
$classroms = $update_classrom->get_result()->fetch_assoc(); 
$location = $classroms['location'];
$title = $classroms['title']; 


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (empty($location)) {
        array_push($errors, 'Floor is required');
    }
    if (empty($title)) {
        array_push($errors, 'Title is required');
    }


    if (!count($errors)) {
        $update_classroom = $mysqli->prepare('update classrooms set location=?, title =? where id = ?'); 
        $update_classroom->bind_param('ssi', $dbLocation ,$dbTitle, $id_classroom);
        $dbLocation = $_POST['location']; 
        $dbTitle = $_POST['title']; 
        $id_classroom = $_GET['id']; 
        $update_classroom->execute(); 
        $_SESSION['success_message'] = "Has been classroom modify successfully"; 

    
        if($update_classroom->error){
            array_push($errors, $update_classrooms->error); 
    }else{
        echo "<script>location.href = 'index.php' </script>"; 

    }
    }

}

?>


<?php if($_SESSION['role_id'] == 7) { ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
    <div class="col-md-12 col-lg-12 order-2 mb-4">
    <div class="card">
        <h5 class="card-header">Edit classroom :</h5>
        <div class="card-body">
            <?php include __DIR__ . '/../../template/errors.php' ?>
            <div>
                <form action="" method="post">
                    <label for="defaultFormControlInput" class="form-label">Floor :</label>
                    <input type="text" name='location' class="form-control" id="defaultFormControlInput" placeholder="Frist floor" value="<?php echo $location?>" aria-describedby="defaultFormControlHelp" />

                    <label for="defaultFormControlInput" class="form-label">Title :</label>
                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="1/1" value="<?php echo $title?>" aria-describedby="defaultFormControlHelp" />

                    <div class="demo-vertical-spacing">
                        <div class="d-block">
                            <button class="btn btn-success" for="btn-check">Edit classroom</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    </div>
</div>
<?php 
} else {
    die("You are not allowed to access this page"); 
}
?>



<?php require_once __DIR__ . '/../../template/footer.php' ?>