<?php
$title_pages = "Classrooms";
require_once __DIR__ . '/../../template/header.php';

$classrooms = $mysqli->query("select * from classrooms order by title")->fetch_all(MYSQLI_ASSOC);
?>



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
        </div>
    </div>

    <div class="row">
        <!-- Bootstrap Table with Header - Light -->
        <div class="col-md-6 col-lg-6 order-2 mb-4">
            <div class="card overflow-hidden mb-4" style="height: 570px">
            <?php include  __DIR__ . '/../../template/messages.php'?>
                <h5 class="card-header">All classrooms : <?php echo count($classrooms)?></h5>
            
                <div class="table-responsive text-nowrap ">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Floor</th>
                                <th>Title</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php foreach ($classrooms as $classroom) : ?>
                                <tr>
                                    <td><?php echo $classroom['id'] ?></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $classroom['location'] ?></strong></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $classroom['title'] ?></strong></td>
                                    <?php if($_SESSION['role_id'] == 7 ) { ?>
                                    <td>
                                        <a href="edit.php?id=<?php echo $classroom['id']?>" type="button" class="btn btn-sm btn-warning"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <form action="" method="post" style="display: inline-block">
                                            <input type="hidden" name="id" value="<?php echo $classroom['id']?>">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger"><i class="bx bx-trash me-1"></i>Delete</button>
                                        </form>
                                    </td>
                                    <?php } ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php if($_SESSION['role_id'] == 7 ) { ?>
        <?php require_once 'create.php' ?>
        <?php } ?> 
    </div>
</div>

<?php 
if(isset($_POST['id'])){

    $st = $mysqli->prepare('delete from classrooms where id = ?'); 
    $st->bind_param('i', $id_classroom); 
    $id_classroom = $_POST['id']; 
    $st->execute();

    echo "<script>location.href = 'index.php' </script>"; 
}
?>

<?php require_once __DIR__ . '/../../template/footer.php' ?>