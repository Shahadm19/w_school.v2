<?php
$errors = [];
$location = ''; 
$title = '';

// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 7) {   
//     die('You are not allowed to access this page');
// }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $location = mysqli_real_escape_string($mysqli, $_POST['location']);
    if (empty($location)) {
        array_push($errors, 'Floor is required');
    }
    $title = mysqli_real_escape_string($mysqli, $_POST['title']);
    if (empty($title)) {
        array_push($errors, 'Title is required');
    }

    // if (!count($errors)) {
    //     $classroom_exists = $mysqli->query("select * from classrooms where location='$location' limit 1");
    //     if ($classroom_exists->num_rows) {
    //         array_push($errors, "Location is already registered");
    //     }
    // }

    if(!count($errors)){
    $add_classroom = $mysqli->prepare("insert into classrooms (location, title) values (?,?)"); 
    $add_classroom->bind_param('ss',$dbLocation, $dbTitle); 
    $dbLocation = $location; 
    $dbTitle = $title; 
    $add_classroom->execute();

    $_SESSION['success_message'] = "Classroom add successfully"; 
    echo "<script>location.href = 'index.php' </script>"; 

    }
 
 
}

?>

<?php if($_SESSION['role_id'] == 7) { ?>
<div class="col-md-6 col-lg-6 order-2 mb-4">
    <div class="card">
        <h5 class="card-header">Add new classroom:</h5>
        <div class="card-body">
            <?php include __DIR__ . '/../../template/errors.php' ?>
            <div>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">
                    <label for="defaultFormControlInput" class="form-label">Floor : </label>
                    <input type="text" name='location' class="form-control" id="defaultFormControlInput" placeholder="first floor" aria-describedby="defaultFormControlHelp" />
                    <label for="defaultFormControlInput" class="form-label">Titles : </label>
                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="1/1" aria-describedby="defaultFormControlHelp" />

                    <div class="demo-vertical-spacing">
                        <div class="d-block">
                            <button class="btn btn-success" for="btn-check">Add classroom</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php } else {
   die( "You are not allowed to access this page"); 
} ?> 