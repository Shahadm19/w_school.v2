<?php
$title_pages = "Edit class";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
}

$courses = $mysqli->query("select *, courses.title as course_title from courses order by id")->fetch_all(MYSQLI_ASSOC);
$teachers = $mysqli->query("select *, concat(users.frist_name, ' ', users.last_name) as full_name from users where role_id = 8")->fetch_all(MYSQLI_ASSOC);
$classrooms = $mysqli->query("select *, classrooms.title as classroom_title from classrooms order by id")->fetch_all(MYSQLI_ASSOC);

$update_class = $mysqli->prepare("select *, classes.id as class_id, 
                        courses.title as course_title, 
                        concat(users.frist_name, ' ', users.last_name) as full_name, 
                        classrooms.title as classroom_title, classrooms.location as floor,
                        classrooms.id as classrooms_id, 
                        roles.title as role_title
                        from classes 
                        left join courses on classes.course_id = courses.id
                        left join users on classes.teacher_id = users.id 
                        left join roles on users.role_id = roles.id
                        left join classrooms on classes.classroom_id = classrooms.id
                        where classes.id = ? limit 1"); 
$update_class->bind_param('i', $id_class);
$id_class = $_GET['id']; 
$update_class->execute(); 
$classes = $update_class->get_result()->fetch_assoc(); 


$course_id = $classes['course_id']; 
$course_title = $classes['course_title']; 

$full_name = $classes['full_name']; 
$role_id = $classes['role_id'];
$role_title = $classes['role_title'];
$teacher_id = $classes['teacher_id']; 

$classrooms_id = $classes['classrooms_id']; 
$classroom_title = $classes['classroom_title']; 






if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // if(empty($course_id)){array_push($errors, "Course title is required");}
    // if(empty($teacher_id)){array_push($errors, "Select teacher is required");}
    // if(empty($classroom_id)){array_push($errors, "Classroom is required");}


    if (!count($errors)) {
        $update_class = $mysqli->prepare('update classes set course_id=?, teacher_id=?, classroom_id=? where id = ?'); 
        $update_class->bind_param('iiii', $dbCourse_id, $dbTeacher_id, $dbClassroom_id, $dbClass_id ); 
        $dbCourse_id = $_POST['course_id']; 
        $dbTeacher_id = $_POST['teacher_id']; 
        $dbClassroom_id =$_POST['classroom_id']; 
        $dbClass_id = $_GET['id']; 
        $update_class->execute();
        $_SESSION['success_message'] = "Has been class modify successfully"; 
       
    
        if($update_class->error){
            array_push($errors, $update_class->error); 
    }else{
        echo "<script>location.href = 'index.php' </script>"; 

    }
    }

}

?>



<?php if($_SESSION['role_id'] == 7) { ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Edit class</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="" method="post">
 

                        <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Course :</label>
                                <select class="form-select" name="course_id" id="exampleFormControlSelect1" value="<?php echo $course_id?>">
                                <option value="<?php echo $course_id ?>"><?php echo $course_title?></option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']?>"><?php echo $course['title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>


                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select teacher :</label>
                                <select class="form-select" name="teacher_id" id="exampleFormControlSelect1" value="<?php echo $teacher_id?>">
                                <option value="<?php echo $teacher_id ?>"><?php echo $full_name?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']?>"><?php echo $teacher['full_name']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>




                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Classroom :</label>
                                <select class="form-select" name="classroom_id" id="exampleFormControlSelect1" value="<?php echo $classroom_id?>">
                                <option value="<?php echo $classrooms_id ?>"><?php echo $classroom_title?></option>
                                <?php foreach ($classrooms as $classroom): ?>
                                    <option value="<?php echo $classroom['id']?>"><?php echo $classroom['title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>


                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Update user !</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } else {
    die("You are not allowed to access this page");
}?>


<?php require_once __DIR__ . '/../../template/footer.php' ?>