<?php
$title_pages = 'Create class';
require_once __DIR__ . '/../../template/header.php';
$errors = [];


$courses = $mysqli->query("select *, courses.title as course_title from courses order by id")->fetch_all(MYSQLI_ASSOC);
$teachers = $mysqli->query("select *, concat(users.frist_name, ' ', users.last_name) as full_name from users where role_id = 8")->fetch_all(MYSQLI_ASSOC);
$classrooms = $mysqli->query("select *, classrooms.title as classroom_title from classrooms order by id")->fetch_all(MYSQLI_ASSOC);

// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 7) {   
//     die('You are not allowed to access this page');
// }




if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $course_id = mysqli_real_escape_string($mysqli, $_POST['course_id']); 
    $teacher_id = mysqli_real_escape_string($mysqli, $_POST['teacher_id']); 
    $classroom_id = mysqli_real_escape_string($mysqli, $_POST['classroom_id']); 


    if(empty($course_id)){array_push($errors, "Course title is required");}
    if(empty($teacher_id)){array_push($errors, "Select teacher is required");}
    if(empty($classroom_id)){array_push($errors, "Classroom is required");}



    if(!count($errors)){
    $add_class = $mysqli->prepare("insert into classes (course_id, teacher_id, classroom_id) values (?,?,?)"); 
    $add_class->bind_param('iii', $dbCourse_id, $dbTeacher_id, $dbClassroom_id ); 
    $dbCourse_id = $_POST['course_id']; 
    $dbTeacher_id = $_POST['teacher_id']; 
    $dbClassroom_id =$_POST['classroom_id']; 
    $add_class->execute();

    // $_SESSION['logged_in'] = true; 
    $_SESSION['success_message'] = "Class add successfully"; 
    // header('location:index.php'); 
    echo "<script>location.href = 'index.php' </script>"; 

  }
} 



?> 



<!-- Content wrapper -->
<?php if($_SESSION['role_id'] == 7) { ?>
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Add new class</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">                   

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Course :</label>
                                <select class="form-select" name="course_id" id="exampleFormControlSelect1" value="<?php echo $course_id?>">
                                <option value="">Select one</option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']?>"><?php echo $course['course_title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select teacher :</label>
                                <select class="form-select" name="teacher_id" id="exampleFormControlSelect1" value="<?php echo $teacher_id?>">
                                <option value="">Select one</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']?>"><?php echo $teacher['full_name']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Select Classroom :</label>
                                <select class="form-select" name="classroom_id" id="exampleFormControlSelect1" value="<?php echo $classroom_id?>">
                                <option value="">Select one</option>
                                <?php foreach ($classrooms as $classroom): ?>
                                    <option value="<?php echo $classroom['id']?>"><?php echo $classroom['classroom_title']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>


                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Add class</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
 } else {
    die('You are not allowed to access this page');} 
    ?>

<?php require_once __DIR__ . '/../../template/footer.php' ?>