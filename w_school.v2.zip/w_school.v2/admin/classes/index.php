<?php
$title_pages = 'Classes';
require_once __DIR__ . '/../../template/header.php';

$classes = $mysqli->query("select *, classes.id as class_id, 
                        courses.title as course_title, 
                        concat(users.frist_name, ' ', users.last_name) as full_name, 
                        classrooms.title as classroom_title, classrooms.location as floor
                        from classes 
                        left join courses on classes.course_id = courses.id
                        left join users on classes.teacher_id = users.id 
                        left join classrooms on classes.classroom_id = classrooms.id")->fetch_all(MYSQLI_ASSOC);
?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="col-sm-7">
                        <div class="card-body">
                            <h5 class="card-title text-primary">All classes</h5>
                            <p class="mb-4">
                                Here are all <span class="fw-bold">classes and courses data</span>,
                                <?php if($_SESSION['role_id'] == 7 ){?>
                                also, can you additional new class
                                <?php } ?>
                            </p>
                            <?php if($_SESSION['role_id'] == 7 ){?>
                            <a href="create.php" class="btn btn-sm btn-outline-primary">ADD</a>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                            <img src="<?php echo $config['app_url'] ?>assets/img/illustrations/man-with-laptop-light.png" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <div class="row">
            <!-- Bootstrap Table with Header - Light -->
            <div class="col-md-12 col-lg-12 order-2 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                    <?php include  __DIR__ . '/../../template/messages.php'?>
                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search coures" class="form-control" title="Type in a name">

                    </div>

                    <div class="table-responsive text-nowrap">
                        <table id="myTable" class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Course</th>
                                    <th>Teacher</th>
                                    <th>Classroom</th>
                                    <th>Floor</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php foreach ($classes as $class) : ?>
                                    <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $class['course_title']; ?></strong></td>
                                        <td><?php echo $class['full_name']?></td>
                                        <td>
                                            <div class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php echo $class['classroom_title'] ?>
                                            </div>
                                        </td>

                                        <td>
                                            <div class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                                <?php echo $class['floor'] ?>
                                            </div>
                                        </td>
                                        <?php if($_SESSION['role_id'] == 7 ){?>
                                        <td>
                                            <div class="dropdown">
                                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                    <i class="bx bx-dots-vertical-rounded"></i>
                                                </button>

                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="edit.php?id=<?php echo $class['class_id'] ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                                    <form action="" method="post" style="display: inline-block">
                                                        <input type="hidden" name="class_id" value="<?php echo $class['class_id'] ?>">
                                                        <button onclick="return confirm('Are you sure?')" class="dropdown-item"><i class="bx bx-trash me-1"></i>Delete</button>
                                                    </form>

                                                </div>
                                            </div>
                                        </td>
                                        <?php } ?> 
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->


    <?php
    
    if (isset($_POST['class_id'])) {

        $st = $mysqli->prepare('delete from classes where id = ?');
        $st->bind_param('i', $id_class);
        $id_class = $_POST['class_id'];
        $st->execute();

        echo "<script>location.href = 'index.php' </script>";
    }
    ?>

<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");


  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
  
}



</script>
    <?php require_once __DIR__ . '/../../template/footer.php' ?>