<?php
$title_pages = "Exams result";
require_once __DIR__ . '/../../template/header.php';


$user_id = $_SESSION['user_id'];  


if($_SESSION['role_id'] == 7 ) { 

$exam_result = $mysqli->query("select exam_result.id as exam_result_id, student_id, exam_id, score, 
                        concat(s.frist_name, ' ', s.last_name) as student_name, 
                        concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                        courses.short_name as course_short_name, classrooms.title as classroom_title
                        from exam_result
                        left join exams on exam_result.exam_id = exams.id 
                        left join classes on exams.class_id = classes.id 
                        left join classrooms on classes.classroom_id = classrooms.id
                        left join courses on classes.course_id = courses.id
                        left join users s on exam_result.student_id = s.id
                        inner join users t on classes.teacher_id = t.id
                        ")->fetch_all(MYSQLI_ASSOC);


 } elseif($_SESSION['role_id'] == 8 ) {
    $exam_result = $mysqli->query("select exam_result.id as exam_result_id, student_id, exam_id, score, teacher_id, 
                            concat(s.frist_name, ' ', s.last_name) as student_name, 
                            concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                            courses.short_name as course_short_name, classrooms.title as classroom_title
                            from exam_result
                            left join exams on exam_result.exam_id = exams.id 
                            left join classes on exams.class_id = classes.id 
                            left join classrooms on classes.classroom_id = classrooms.id
                            left join courses on classes.course_id = courses.id
                            left join users s on exam_result.student_id = s.id
                            inner join users t on classes.teacher_id = t.id
                            where classes.teacher_id = '$user_id'
                            order by exam_result.student_id
                            ")->fetch_all(MYSQLI_ASSOC);
 } else{
    $exam_result = $mysqli->query("select exam_result.id as exam_result_id, student_id, exam_id, score, 
                            concat(s.frist_name, ' ', s.last_name) as student_name, 
                            concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                            courses.short_name as course_short_name, classrooms.title as classroom_title
                            from exam_result
                            left join exams on exam_result.exam_id = exams.id 
                            left join classes on exams.class_id = classes.id 
                            left join classrooms on classes.classroom_id = classrooms.id
                            left join courses on classes.course_id = courses.id
                            left join users s on exam_result.student_id = s.id
                            inner join users t on classes.teacher_id = t.id
                            where exam_result.student_id = '$user_id'
                            order by exam_result.student_id
                            ")->fetch_all(MYSQLI_ASSOC);
 }

?>

 

<div class="container-xxl flex-grow-1 container-p-y">


    <div class="row">
    <?php include  __DIR__ . '/../../template/messages.php'?>
    <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
        <?php require_once 'create.php' ?>
        <?php } ?>

        <!-- Bootstrap Table with Header - Light -->
        <div class="col-md-8 col-lg-12 order-2 mb-4">
            <div class="card overflow-hidden mb-4 h-100" style="height: 570px"> 
            
                <div class="card-header">
                    <h5>Exam result :</h5>
                    <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search Course">
    </div>
                <div class="table-responsive text-nowrap">

                
                    <table id="myTable" class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Student</th>
                                <th>Exam</th>
                                <th>Teacher</th>
                                <th>Score</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php foreach ($exam_result as $result) : ?>
                                <tr>
                                    <td><?php echo $result['exam_result_id'] ?></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i><strong>
                                        <?php echo $result['student_name']?>
                                    </strong></td>
                                    <td>
                                        <?php echo $result['course_short_name']?> (<?php echo $result['classroom_title']?>)
                                    </td> 
                                    <td><?php echo $result['teacher_name']?> </td>
                                    <td> % <?php echo $result['score']?></td>
                                    <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
                                    <td>
                                        <a href="edit.php?id=<?php echo $result['exam_result_id']?>" type="button" class="btn btn-sm btn-warning"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                        <form action="" method="post" style="display: inline-block">
                                            <input type="hidden" name="exam_result_id" value="<?php echo $result['exam_result_id']?>">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger"><i class="bx bx-trash me-1"></i>Delete</button>
                                        </form>
                                    </td>
                             <?php } ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
if(isset($_POST['exam_result_id'])){

    $st = $mysqli->prepare('delete from exam_result where id = ?'); 
    $st->bind_param('i', $id_exam_result); 
    $id_exam_result = $_POST['exam_result_id']; 
    $st->execute();

    echo "<script>location.href = 'index.php' </script>"; 
}
?>

<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>


<?php require_once __DIR__ . '/../../template/footer.php' ?>