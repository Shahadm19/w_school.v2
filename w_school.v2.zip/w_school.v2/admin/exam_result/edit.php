<?php
$title_pages = "Edit exam result";
$errors = [];
$title = '';
$score = '';

require_once __DIR__ . '/../../template/header.php';

if (!isset($_GET['id']) || !$_GET['id']) {
    die('Missing id parameter');
}


$students = $mysqli->query("select users.id as student_id, concat(users.frist_name, ' ', users.last_name) as student_name from users where role_id = 9")->fetch_all(MYSQLI_ASSOC);

$exams = $mysqli->query("select *, exams.id as exam_id, 
                     courses.title as course_title,
                     concat(users.frist_name, ' ', users.last_name) as full_name, 
                     classrooms.location as classroom_floor, classrooms.title as classroom_title
                     from exams
                     left join classes on exams.class_id = classes.id
                     left join courses on classes.course_id = courses.id 
                     left join users on classes.teacher_id = users.id 
                     left join classrooms on classes.classroom_id = classrooms.id
                     order by exams.class_id")->fetch_all(MYSQLI_ASSOC);


$update_exam_result = $mysqli->prepare("select *, exam_result.id as exam_result_id, student_id, exam_id, score, 
                        concat(s.frist_name, ' ', s.last_name) as student_name, 
                        concat(t.frist_name, ' ', t.last_name) as teacher_name, 
                        courses.short_name as course_short_name, classrooms.title as classroom_title
                        from exam_result
                        left join exams on exam_result.exam_id = exams.id 
                        left join classes on exams.class_id = classes.id 
                        left join classrooms on classes.classroom_id = classrooms.id
                        left join courses on classes.course_id = courses.id
                        left join users s on exam_result.student_id = s.id
                        inner join users t on classes.teacher_id = t.id
                        where exam_result.id = ? limit 1");
$update_exam_result->bind_param('i', $id_exam_result);
$id_exam_result = $_GET['id'];
$update_exam_result->execute();
$exam_results = $update_exam_result->get_result()->fetch_assoc();

$student_id = $exam_results['student_id'];
$student_name = $exam_results['student_name'];
$exam_id = $exam_results['exam_id'];
$score = $exam_results['score'];
$course_short_name = $exam_results['course_short_name'];
$classroom_title = $exam_results['classroom_title']; 
$teacher_name = $exam_results['teacher_name'];


// student  Exam Teacher Score

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (!count($errors)) {
        $update_exam_result = $mysqli->prepare('update exam_result set student_id=?, exam_id=?, score=? where id = ?');
        $update_exam_result->bind_param('iiii', $dbStudent_id, $dbExam_id, $dbScore, $dbExam_result_id);
        $dbStudent_id = $_POST['student_id'];
        $dbExam_id = $_POST['exam_id'];
        $dbScore = $_POST['score'];
        $dbExam_result_id = $_GET['id'];
        $update_exam_result->execute();
        $_SESSION['success_message'] = "Has been exam result modify successfully"; 



        if ($update_exam_result->error) {
            array_push($errors, $update_exam_result->error);
        } else {
            echo "<script>location.href = 'index.php' </script>";
        }
    }
}

?>




<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Edit exam result:</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="" method="post">

                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Student :</label>
                                <select class="form-select" name="student_id" id="exampleFormControlSelect1" value="<?php echo $student_id ?>">
                                <option value="<?php echo $student_id?>"><?php echo $student_name ?></option>   
                                <?php foreach ($students as $student) : ?>
                                        <option value="<?php echo $student['student_id'] ?>">
                                            <?php echo $student['student_name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>


                            <div class="mb-3">
                                <label for="exampleFormControlSelect1" class="form-label">Exam :</label>
                                <select class="form-select" name="exam_id" id="exampleFormControlSelect1" value="<?php echo $exam_id ?>">
                                    <option value="<?php echo $exam_id?>">
                                    <?php echo $course_short_name?>
                                    ( <?php echo $classroom_title ?> ) 
                                    - <?php echo $teacher_name ?>
                                </option>
                                <?php foreach ($exams as $exam) : ?>
                                        <option value="<?php echo $exam['exam_id'] ?>">
                                            <?php echo $exam['course_title'] ?>
                                            ( <?php echo $exam['classroom_title'] ?> )
                                            -
                                            <?php echo $exam['full_name'] ?>

                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <label for="defaultFormControlInput" class="form-label">Score : </label>
                            <input type="text" name='score' class="form-control" id="defaultFormControlInput" placeholder="98" aria-describedby="defaultFormControlHelp" value="<?php echo $score ?>" />




                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Update exam result !</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php require_once __DIR__ . '/../../template/footer.php' ?>