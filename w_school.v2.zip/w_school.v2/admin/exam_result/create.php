<?php
$errors = [];
$title = '';


$students = $mysqli->query("select *, users.frist_name as user_frist_name, users.last_name as user_last_name from users where role_id = 9")->fetch_all(MYSQLI_ASSOC);



if ($_SESSION['role_id'] == 8) {
    $exams = $mysqli->query("select *, classes.id as class_id, 
                courses.title as course_title, 
                users.frist_name as user_frist_name, users.last_name as user_last_name, 
                classrooms.location as classroom_floor, classrooms.title as classroom_title
                from classes 
                left join courses on classes.course_id = courses.id 
                left join users on classes.teacher_id = users.id 
                left join classrooms on classes.classroom_id = classrooms.id
                where users.id = '$user_id'
                order by classes.id ")->fetch_all(MYSQLI_ASSOC);
} else {
    $exams = $mysqli->query("select *, exams.id as exam_id, 
                courses.title as course_title,
                users.frist_name as user_frist_name, users.last_name as user_last_name, 
                classrooms.location as classroom_floor, classrooms.title as classroom_title
                from exams
                left join classes on exams.class_id = classes.id
                left join courses on classes.course_id = courses.id 
                left join users on classes.teacher_id = users.id 
                left join classrooms on classes.classroom_id = classrooms.id
                order by exams.class_id")->fetch_all(MYSQLI_ASSOC);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = mysqli_real_escape_string($mysqli, $_POST['student_id']);
    if (empty($student_id)) {
        array_push($errors, 'Select student is required');
    }
    $exam_id = mysqli_real_escape_string($mysqli, $_POST['exam_id']);
    if (empty($exam_id)) {
        array_push($errors, 'Select one is required');
    }
    $score = mysqli_real_escape_string($mysqli, $_POST['score']);
    if (empty($score)) {
        array_push($errors, 'Score is required');
    }

    if (!count($errors)) {
        $result_exists = $mysqli->query("select * from exam_result where student_id='$student_id' and exam_id='$exam_id' limit 1");
        if ($result_exists->num_rows) {
            array_push($errors, "This result is already registered");
        }
    }

    if (!count($errors)) {
        $add_result = $mysqli->prepare("insert into exam_result (student_id, exam_id, score) values (?,?,?)");
        $add_result->bind_param('iii', $dbStudent_id, $dbExam_id, $dbScore);
        $dbStudent_id = $_POST['student_id'];
        $dbExam_id = $_POST['exam_id'];
        $dbScore = $score;
        $add_result->execute();

        $_SESSION['success_message'] = "Exam add successfully";
        echo "<script>location.href = 'index.php' </script>";
    }
}

?>
<?php if ($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8) { ?>

    <div class="col-md-12 col-lg-12 order-2 mb-4">
        <div class="card">
            <h5 class="card-header">Add exam result:</h5>
            <div class="card-body">
                <?php include __DIR__ . '/../../template/errors.php' ?>
                <div>

                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">
                        <div class="row">
                            <div class="col-3">
                                <div class="mb-3">
                                    <label for="exampleFormControlSelect1" class="form-label">Student :</label>
                                    <select class="form-select" name="student_id" id="exampleFormControlSelect1" value="<?php echo $student_id ?>">
                                        <option value="">Select one</option>
                                        <?php foreach ($students as $student) : ?>
                                            <option value="<?php echo $student['id'] ?>">
                                                <?php echo $student['user_frist_name'] ?> <?php echo $student['user_last_name'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="mb-3">
                                    <label for="exampleFormControlSelect1" class="form-label">Exam :</label>
                                    <select class="form-select" name="exam_id" id="exampleFormControlSelect1" value="<?php echo $exam_id ?>">
                                        <option value="">Select one</option>
                                        <?php foreach ($exams as $exam) : ?>
                                            <option value="<?php echo $exam['exam_id'] ?>">
                                                <?php echo $exam['course_title'] ?>
                                                ( <?php echo $exam['classroom_title'] ?> )
                                                -
                                                <?php echo $exam['user_frist_name'] ?> <?php echo $exam['user_last_name'] ?>

                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-3">
                                <label for="defaultFormControlInput" class="form-label">Score : </label>
                                <input type="text" name='score' class="form-control" id="defaultFormControlInput" placeholder="98" aria-describedby="defaultFormControlHelp" />
                            </div>

                            <div class="col-3">
                                <div class="demo-vertical-spacing">
                                    <div class="d-block pt-3">
                                        <button class="btn btn-success" for="btn-check">Add exam result</button>
                                    </div>
                                </div>
                            </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php
} else {
    die("You are not allowed to access this page");
}
?>