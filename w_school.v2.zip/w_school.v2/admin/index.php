<?php

$title_pages = 'Dashboard';
require_once __DIR__ . '/../template/header.php';

if (!isset($_SESSION['role_id'])) {
  if ($_SESSION['role_id'] !== 7 && $_SESSION['role_id'] !== 8 && $_SESSION['role_id'] !== 9){
    die('You are not allowed to access this page');
  }
}


$students = $mysqli->query("select * from users where role_id = 9 ")->fetch_all(MYSQLI_ASSOC);

$count_subject = $mysqli->query("select count(users.id) as count_users,
courses.title as courses_title,
 courses.short_name as course_short_name
 from class_student 
 right join users on class_student.student_id = users.id 
 right join classes on class_student.class_id = classes.id 
 RIGHT join courses on classes.course_id = courses.id
group by courses.id
order by count_users DESC
");

?>

<!-- Content wrapper -->
<div class="content-wrapper">
  <!-- Content -->

  <div class="container-xxl flex-grow-1 container-p-y">

    <div class="row">
      <?php include __DIR__ . '/../template/messages.php'; ?>
      <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
      <!-- Order Statistics -->
      <div class="col-md-6 col-lg-4 col-xl-4 order-0 mb-4">
        <div class="card h-100">
          <div class="card-header d-flex align-items-center justify-content-between pb-0">
            <div class="card-title mb-0">
              <h5 class="m-0 me-2">Student:</h5>
              <small class="text-muted">-</small>
            </div>
          </div>
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <div class="d-flex flex-column align-items-center gap-1">
                <h2 class="mb-2"><?php echo count($students)?></h2>
                <span>Total Student</span>
              </div>
              <div id="orderStatisticsChart"></div>
            </div>
            <ul class="p-0 m-0">
              <li class="d-flex mb-4 pb-1">
                <div class="avatar flex-shrink-0 me-3">
                  <span class="avatar-initial rounded bg-label-primary">
                    <i class="">1</i>
                  </span>
                </div>
                <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                  <div class="me-2">
                    <h6 class="mb-0">First Secondary</h6>
                    <small class="text-muted"></small>
                  </div>
                  <div class="user-progress">
                    <small class="fw-semibold">205</small>
                  </div>
                </div>
              </li>
              <li class="d-flex mb-4 pb-1">
                <div class="avatar flex-shrink-0 me-3">
                  <span class="avatar-initial rounded bg-label-success">
                    <i class=""></i>2</span>
                </div>
                <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                  <div class="me-2">
                    <h6 class="mb-0">Second Secondary</h6>
                    <small class="text-muted"></small>
                  </div>
                  <div class="user-progress">
                    <small class="fw-semibold">238</small>
                  </div>
                </div>
              </li>
              <li class="d-flex mb-4 pb-1">
                <div class="avatar flex-shrink-0 me-3">
                  <span class="avatar-initial rounded bg-label-info">
                    <i class="">3</i></span>
                </div>
                <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                  <div class="me-2">
                    <h6 class="mb-0">Secondary Third</h6>
                    <small class="text-muted"></small>
                  </div>
                  <div class="user-progress">
                    <small class="fw-semibold">149</small>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!--/ Order Statistics -->

      <!-- Bootstrap Table with Header - Light -->
      <div class="col-md-12 col-lg-8 order-2 mb-4">
        <div class="card h-100">
          <h5 class="card-header">Subject</h5>
          <div class="table-responsive text-nowrap">
            <table class="table">
              <thead class="table-light">
                <tr>
                  <th>Courses</th>
                  <th>Short name</th>
                  <th>Student</th>
                </tr>
              </thead>
              <tbody class="table-border-bottom-0">
                <?php foreach($count_subject as $count_sub) : ?>
                <tr>
                  <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $count_sub['courses_title']?></strong></td>
                  <td><?php echo $count_sub['course_short_name']?></td>
                  <td>
                    <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                      <?php echo $count_sub['count_users']?>
                    </ul>
                  </td>
                </tr>
                  <?php endforeach ;  ?>

    

                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php 
    } else {
      require_once __DIR__ . '/students.php';
      } 
      ?>
  </div>
  <!-- / Content -->
  <?php
  require_once __DIR__ . '/../template/footer.php';
  ?>