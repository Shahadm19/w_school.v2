<?php
$title_pages = "Edit Course";
$errors = [];
$title = '';

require_once __DIR__ . '/../../template/header.php';

if(!isset($_GET['id']) || !$_GET['id']){
    die('Missing id parameter'); 
} 


$update_course = $mysqli->prepare("select * from courses where id = ? limit 1"); 
$update_course->bind_param('i', $id_course);
$id_course = $_GET['id']; 
$update_course->execute(); 
$courses = $update_course->get_result()->fetch_assoc(); 
$title = $courses['title']; 
$short_name = $courses['short_name'];
$description = $courses['description'];



if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if(empty($title)){array_push($errors, "Title name is required");}
    if(empty($short_name)){array_push($errors, "Short name is required");}



    if (!count($errors)) {
        $update_course = $mysqli->prepare('update courses set title=?, short_name=?, description=? where id = ?'); 
        $update_course->bind_param('sssi', $dbTitle, $dbShort_name, $dbDescription, $dbCourse_id); 
        $dbTitle = $_POST['title']; 
        $dbShort_name = $_POST['short_name']; 
        $dbDescription = $_POST['description']; 
        $dbCourse_id = $_GET['id']; 
        $update_course->execute();
        $_SESSION['success_message'] = "Has been course modify successfully"; 
       
    
        if($update_course->error){
            array_push($errors, $update_course->error); 
    }else{
        echo "<script>location.href = 'index.php' </script>"; 

    }
    }

}

?>



<?php if($_SESSION['role_id'] == 7) { ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Update course:</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Title :</label>
                                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="Mohammed" value="<?php echo $title?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Short name :</label>
                                    <input type="text" name='short_name' class="form-control" id="defaultFormControlInput" placeholder="Alsaleh" value="<?php echo $short_name?>" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <label for="exampleFormControlTextarea1" class="form-label">Description :</label>
                                    <textarea class="form-control" id="exampleFormControlTextarea1" name='description' rows="3"><?php echo $description?></textarea>
                                </div>
                            </div>

 

                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Update course!</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
} else {
    die("You are not allowed to access this page");
}
?>


<?php require_once __DIR__ . '/../../template/footer.php' ?>