<?php
$title_pages = 'Create Course';
require_once __DIR__ . '/../../template/header.php';
$errors = [];
$title = ''; 
$short_name = ''; 
$description = ''; 



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $title = mysqli_real_escape_string($mysqli, $_POST['title']); 
    $short_name = mysqli_real_escape_string($mysqli, $_POST['short_name']); 
    $description = mysqli_real_escape_string($mysqli, $_POST['description']); 


    if(empty($title)){array_push($errors, "Title name is required");}
    if(empty($short_name)){array_push($errors, "Short name is required");}


    if (!count($errors)) {
        $title_exists = $mysqli->query("select id, title from courses where title ='$title' limit 1"); 
        if($title_exists->num_rows){
            array_push($errors, "Title name already registered"); 
        }
    }

    if (!count($errors)) {
        $short_name_exists = $mysqli->query("select id, short_name from courses where short_name ='$short_name' limit 1"); 
        if($short_name_exists->num_rows){
            array_push($errors, "Short name already registered"); 
        }
    }

    if(!count($errors)){
    $add_course = $mysqli->prepare("insert into courses (title, short_name, description) values (?,?,?)"); 
    $add_course->bind_param('sss', $dbTittle, $dbShort_name, $dbDescription); 
    $dbTittle = $title; 
    $dbShort_name = $short_name; 
    $dbDescription = $description; 
    $add_course->execute();

        // $_SESSION['logged_in'] = true; 
        $_SESSION['success_message'] = "Course add successfully"; 
        // header('location:index.php'); 
        echo "<script>location.href = 'index.php' </script>"; 
    
    echo "<script>location.href = 'index.php' </script>"; 

  }
} 



?> 


<?php if($_SESSION['role_id'] == 7) { ?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <!-- Input Sizing -->
            <div class="card mb-4">
                <h5 class="card-header">Add new course</h5>
                <div class="card-body">
                    <?php include __DIR__ . '/../../template/errors.php' ?>
                    <div>
                        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="mulitpart/form-data">
                            <div class="row">
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Title :</label>
                                    <input type="text" name='title' class="form-control" id="defaultFormControlInput" placeholder="Mathematics" value="<?php echo $title?>" />
                                </div>
                                <div class="col-6">
                                    <label for="defaultFormControlInput" class="form-label">Short name :</label>
                                    <input type="text" name='short_name' class="form-control" id="defaultFormControlInput" placeholder="Math102" value="<?php echo $short_name?>" />
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-12">
                                    <label for="exampleFormControlTextarea1" class="form-label">Description :</label>
                                    <textarea class="form-control" id="exampleFormControlTextarea1" name='description' rows="3"></textarea>
                                </div>
                            </div>


                            <div class="demo-vertical-spacing">
                                <div class="d-block">
                                    <button class="btn btn-success" for="btn-check">Add coures</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
} else {
    die("You are not allowed to access this page");
}

?>
<?php require_once __DIR__ . '/../../template/footer.php' ?>