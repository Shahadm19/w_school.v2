<?php
$title_pages = 'Courses';
require_once __DIR__ . '/../../template/header.php';

$courses = $mysqli->query("select * from courses order by title")->fetch_all(MYSQLI_ASSOC);


?>

<!-- Content wrapper -->
<div class="content-wrapper">
  <!-- Content -->
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
      <!-- Bootstrap Table with Header - Light -->
      <div class="col-md-12 col-lg-12 order-2 mb-4">
        <div class="card h-100">
          <div class="row card-header">
          <?php include  __DIR__ . '/../../template/messages.php'?>

            <div class="col-md-10">
              <h5>Courses : <?php echo count($courses) ?></h5>
            </div>
            <?php if($_SESSION['role_id'] == 7 ) { ?>
            <div class="col-md-2">
              <a href="create.php" type="button" class=" btn btn-success"> Add new course</a>
            </div>
            <?php } ?>
            <div class="col-7">
            <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search title">

            </div>

          </div>

          <div class="table-responsive text-nowrap">
            <table id="myTable" class="table">
              <thead class="table-light">
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>Short name</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody class="table-border-bottom-0">
                <?php foreach ($courses as $course) : ?>
                  <tr>
                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $course['id'] ?></strong></td>
                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $course['title'] ?></strong></td>
                    <td><?php echo $course['short_name'] ?></td>
                    <td><?php echo $course['description'] ?></td>
                    <?php if($_SESSION['role_id'] == 7 ) { ?>
                    <td>
                      <div class="dropdown">
                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                          <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="edit.php?id=<?php echo $course['id'] ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                          <form action="" method="post" style="display: inline-block">
                            <input type="hidden" name="id" value="<?php echo $course['id'] ?>">
                            <button onclick="return confirm('Are you sure?')"class="dropdown-item"><i class="bx bx-trash me-1"></i>Delete</button>
                          </form>

                        </div>
                      </div>
                    </td>
                    <?php } ?>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->


  <?php
    
    if (isset($_POST['id'])) {

        $st = $mysqli->prepare('delete from courses where id = ?');
        $st->bind_param('i', $id_course);
        $id_course = $_POST['id'];
        $st->execute();

        echo "<script>location.href = 'index.php' </script>";
    }

    ?>

<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
  <?php
  require_once __DIR__ . '/../../template/footer.php';
  ?>