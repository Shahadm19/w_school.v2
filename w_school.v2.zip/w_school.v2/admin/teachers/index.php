<?php
$title_pages = "Teachers";
require_once __DIR__ . '/../../template/header.php';


if (!isset($_SESSION['role_id'])) {
    if ($_SESSION['role_id'] !== 7 && $_SESSION['role_id'] !== 8 && $_SESSION['role_id'] !== 9) {
        die('You are not allowed to access this page');
    }
}

$teachers = $mysqli->query("select *, 
                        concat(users.frist_name, ' ', users.last_name) as full_name,
                        users.id as user_id,
                        group_concat(courses.title SEPARATOR ',  ') as count_course,
                        classes.id as class_id, courses.id as course_id
                        from users
                        left join classes on users.id = classes.teacher_id 
                        left join courses on classes.course_id = courses.id
                        where role_id = 8
                        group by users.id")->fetch_all(MYSQLI_ASSOC);

?>



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-lg-12 mb-4 order-0">
        </div>
    </div>

    <div class="row">
        <!-- Bootstrap Table with Header - Light -->
        <div class="col-md-12 col-lg-12 order-2 mb-4">
            <div class="card overflow-hidden mb-4" style="height: 570px">
            <?php include  __DIR__ . '/../../template/messages.php'?>
                <div class="card-header">
                    <h5>
                    Teachers :<?php echo count($teachers)?>
                    </h5>
                    <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search teacher">

                </div>



                <div class="table-responsive text-nowrap ">
                    <table  id="myTable" class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>E-mail</th>
                                <th>Course</th>
                                <th>--</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php foreach ($teachers as $teacher) : ?>
                                <tr class="teachers">
                                    <td><?php echo $teacher['id'] ?></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $teacher['full_name'] ?></strong></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $teacher['phone'] ?></strong></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo $teacher['email'] ?></strong></td>
                                    <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong class="text-truncate"><?php echo $teacher['count_course'] ?></strong></td>
                                    <?php if ($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8) { ?>
                                            <td>
                                                <a href="read_more.php?id=<?php echo $teacher['user_id'] ?>" type="button" class="btn btn-sm btn-primary"><i class=""></i>Read more</a>
                                            </td>

                                        <?php } ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>


<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>


<?php require_once __DIR__ . '/../../template/footer.php' ?>