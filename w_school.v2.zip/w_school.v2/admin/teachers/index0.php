<?php

$title_pages = 'Teachers';
require_once __DIR__ . '/../../template/header.php';

if (!isset($_SESSION['role_id'])) {
    if ($_SESSION['role_id'] !== 7 && $_SESSION['role_id'] !== 8 && $_SESSION['role_id'] !== 9) {
        die('You are not allowed to access this page');
    }
}

$teachers = $mysqli->query("select *, 
                        concat(users.frist_name, ' ', users.last_name) as full_name,
                        users.id as user_id,
                        group_concat(courses.title SEPARATOR ', ') as count_course,
                        classes.id as class_id, courses.id as course_id
                        from users
                        left join classes on users.id = classes.teacher_id 
                        left join courses on classes.course_id = courses.id
                        where role_id = 8
                        group by users.id")->fetch_all(MYSQLI_ASSOC);


// $teachers = $mysqli->query("select *, 
// courses.title as course_title, 
// concat(users.frist_name, ' ', users.last_name) as full_name
// from classes 
// left join courses on classes.course_id = courses.id
// left join users on classes.teacher_id = users.id 
// group by users.id")->fetch_all(MYSQLI_ASSOC);


?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">

        <?php include __DIR__ . '/../../template/messages.php'; ?>


        <!-- Bootstrap Table with Header - Light -->

        <div class="row">
            <?php foreach($teachers as $teacher):?>
            <div class="col-md-2 col-lg-3">
                <div class="card text-center mb-3 h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $teacher['full_name']?></h5>
                        <p class="card-text "><?php echo  $teacher['count_course']?></p>
                        <div class="card-footer">
                        <a href="detiles.php?id=<?php echo $teacher['user_id']?>" class="btn btn-primary">Details</a>

                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div> 
</div>
<!-- / Content -->
<?php
require_once __DIR__ . '/../../template/footer.php';
?>