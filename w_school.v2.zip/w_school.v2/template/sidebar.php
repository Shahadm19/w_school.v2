
          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item <?php if($title_pages=='Dashboard'){echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>


            <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 || $_SESSION['role_id'] == 9 ) { ?>
            <!-- Classes -->
            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Classes</span>
            </li>
            <li class="menu-item <?php if($title_pages=='Classes' || $title_pages=='Edit class' || $title_pages=='Create Class')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/classes" class="menu-link">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Basic"> Classes</div>
              </a>
            </li>

            <li class="menu-item <?php if($title_pages=='Courses' || $title_pages=='Edit Course' || $title_pages=='Create Course')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/courses" class="menu-link">
              <i class='menu-icon tf-icons bx bx-notepad'></i>
                <div data-i18n="Basic">Courses</div>
              </a>
            </li>
            <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
            <li class="menu-item <?php if($title_pages=='Classrooms' || $title_pages=='Edit Classroom')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/classrooms" class="menu-link">
              <i class='menu-icon tf-icons bx bx-notepad'></i>
                <div data-i18n="Basic">Classromes</div>
              </a>
            </li>
            <?php } ?> 
           <?php } ?>

           
            <!-- Students -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Students</span></li>

            <!-- Cards -->
            <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
            <li class="menu-item <?php if($title_pages=='Exams')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/exams" class="menu-link">
                <i class="menu-icon tf-icons bx bx-copy-alt"></i>
                <div data-i18n="Boxicons">Exams</div>
              </a>
            </li>
            <?php } ?> 

            <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 || $_SESSION['role_id'] == 9 ) {?>
            <li class="menu-item <?php if($title_pages=='Exams result' || $title_pages=='Edit exam result')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/exam_result" class="menu-link">
                <i class="menu-icon tf-icons bx bx-bookmarks"></i>
                <div data-i18n="Basic">Exam result</div>
              </a>
            </li>
       <?php } ?>
            
       <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8 ) {?>
            <!-- Extended components -->
            <li class="menu-item <?php if($title_pages=='Class student' || $title_pages=='Add class student' || $title_pages=='Detiles student')
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/class_student" class="menu-link">
                <i class="menu-icon tf-icons bx bx-copy"></i>
                <div data-i18n="Basic">Class student</div>
              </a>
            </li>
        <?php } ?>

            <?php if($_SESSION['role_id'] == 7 || $_SESSION['role_id'] == 8  ) { ?>
            <li class="menu-header small text-uppercase"><span class="menu-header-text"> Teachers</span></li>
            <!-- Forms -->
            <!-- <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Form Elements">Mangements</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="forms-basic-inputs.html" class="menu-link">
                    <div data-i18n="Basic Inputs">-</div>
                  </a>
                </li>
              </ul>
            </li> -->
            <li class="menu-item <?php if($title_pages=='Teachers' || $title_pages=='Detiles teacher'  )
            {echo 'active';}?>">
              <a href="<?php echo $config['app_url']?>admin/teachers" class="menu-link">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Form Layouts">Teachers</div>
              </a>
            </li>
            <?php } ?> 



            <?php if($_SESSION['role_id'] == 7 ) {  ?>
            <!-- Settings -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Settings</span></li>
            <li class="menu-item <?php if($title_pages=='Roles' || $title_pages=='Edit role')
            {echo 'active';}?>">
              <a
                href="<?php echo $config['app_url']?>admin/roles"
                class="menu-link"
              >
              <i class="menu-icon tf-icons bx bx-crown"></i>
                <div data-i18n="Support">Roles</div>
              </a>
            </li>
            <li class="menu-item <?php if($title_pages=='Users' || $title_pages=='Edit user' || $title_pages=='Create user')
            {echo 'active';}?>">
              <a
                href="<?php echo $config['app_url']?>admin/users"
                class="menu-link"
              >
                <i class="menu-icon bx bxs-user-check"></i>
                <div data-i18n="Documentation">Users</div>
              </a>
            </li>
          </ul>
          <?php } ?>
        </aside>
        <!-- / Menu -->
