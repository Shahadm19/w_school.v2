<?php 
if(count($errors)):?>

<div class="alert alert-danger" role="alert">
    <?php foreach($errors as $error):?>
        <p><?php echo $error?></p>
    <?php endforeach; ?>
</div>

<?php endif; ?>
<!-- <div class="" role="alert">This is a danger alert — check it out!</div> -->
