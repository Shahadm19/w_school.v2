-- CRUD
create table roles (
    id int(11) unsigned auto_increment primary key, 
    title varchar(16) not null unique
)


--CRUD
create table users(
    id int(11) unsigned auto_increment primary key,
    role_id int(11)unsigned,
    frist_name varchar(30) not null,
    last_name varchar(30) not null,
    phone varchar(14) unique, 
    email varchar(100) unique, 
    password varchar(200), 
    image varchar(30),
    dob date not null, 
    created_at datetime, 
    constraint foreign key(role_id) references roles(id), 
)



--CRUD
create table classrooms(
    id int(11) unsigned auto_increment primary key,
    location varchar(100) not null unique,
    title varchar(30) not null unique 
)



--CRUD
create table courses(
    id int(11) unsigned auto_increment primary key,
    title varchar(30) not null unique,
    short_name varchar(10) not null unique,
    description varchar(255)
)



-- CRUD
create table classes(
    id int(11) unsigned auto_increment primary key,
    course_id int(11) unsigned not null, 
    teacher_id int(11) unsigned not null, 
    classroom_id int(11) unsigned not null,
    constraint foreign key(course_id) references courses(id),
    constraint foreign key(teacher_id) references uesrs(id),
    constraint unique(course_id, teacher_id, classroom_id)
)


-- CRD
create table exams(
    id int(11) unsigned auto_increment primary key,
    class_id int(11) unsigned not null, 
    constraint foreign key(class_id) references classes(id)
)


-- CRD  (INDEX.php)
create table exam_result(
    id int(11) unsigned auto_increment primary key,
    student_id int(11) unsigned not null, 
    exam_id int(11) unsigned not null, 
    score int(3) unsigned not null, 
    constraint foreign key(student_id) references users(id),
    constraint foreign key(exam_id) references exams(id),
    constraint primary key(student_id, exam_id)
)


-- EDIT 
create table class_student(
    student_id int(11) unsigned not null,
    class_id int(11) unsigned not null, 
    constraint foreign key(student_id) references users(id), 
    constraint foreign key(classes_id) references classes(id),
    constraint primary key(student_id, class_id)
)





create table password_resets(
    id int(11) unsigned auto_increment primary key, 
    user_id int(11) unsigned, 
    token varchar(255) not null,
    expires_at datetime, 
    created_at datetime, 
    constraint foreign key(user_id) references users(id),

)


-- INSERT DATA 

insert into roles (title) values ("admin"), ("teacher"), ("parent"), ("student"); 

insert into users ('role_id', 'frist_name','last_name', 'phone', 'email', 'image', 'dob') 
            values ("1", "Shahad", "Almanie", "055555", "shahad@gmail.com", '', '2023-1-13'); 
insert into users ('role_id', 'frist_name','last_name', 'phone', 'email', 'image', 'dob') 
            values ("2", "Noura", "Ahmed", "05511", "noura@gmail.com", '', '2023-1-13'); 






-- QUERES 
select * from users u 
left join roles r 
on r.id = u.role_id ; 


select u.frist_name from users u
where u.role_id = 4 ; 


-- مواد الطلاب 
select user.frist_name, course.title, classroom.title 
from users user 
left join class_student cs on cs.student_id = user.id
left join classes class on class.id = cs.class_id
left join courses course on course_id = class.course_id
left join classrooms classroom on classroom.id = class.classroom_id
where user.role_id = 4;


select user.frist_name , course.title, er.score
from users user
join exam_result er on er.student_id = user.id
join exams exam on exam.id = er.exam_id
join classes class on class.id = exam.class_id
join courses course on course.id = class.course_id
where user.role_id = 4 ; 

