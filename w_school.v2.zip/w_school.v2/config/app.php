<?php
$config = [
    'app_name' => 'W School',
    'lang' => 'en', 
    'dir' => 'ltr',
    'admin_email' => 'admin@admin.com', 
    'app_url' => 'http://localhost/w_school.v2/', 
    'name_project' => 'W school'
]; 